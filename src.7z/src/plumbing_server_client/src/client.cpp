#include "ros/ros.h"
#include "plumbing_server_client/AddInts.h"

int main(int argc, char *argv[])
{
    // 判断参数正确性
    if(argc != 3)
    {
        ROS_INFO("Please input two int numbers.");
        return 1;
    }

    // 构造节点，节点句柄，客户端
    ros::init(argc, argv ,"myClient");
    ros::NodeHandle nh;
    ros::ServiceClient client = nh.serviceClient<plumbing_server_client::AddInts>("add_two_ints");

    // 组织请求数据
    plumbing_server_client::AddInts srv;
    srv.request.num1 = atoi(argv[1]);
    srv.request.num2 = atoi(argv[2]);

    // 等待服务端挂起
    client.waitForExistence();
    // ros::service::waitForService("add_two_ints");

    // 发起请求
    if(client.call(srv))
        ROS_INFO("Sum: %d", srv.response.sum);
    else
    {
        ROS_WARN("Failed to call service add_two_ints!");
        return 1;
    }
    return 0;
}
