#include "ros/ros.h"
#include "plumbing_server_client/AddInts.h"

// 服务端应答请求处理
bool AddAck(plumbing_server_client::AddInts::Request& req,
            plumbing_server_client::AddInts::Response& ack)
{
    if(req.num1 < 0 || req.num2 < 0)
        return false; 
    ack.sum = req.num1 + req.num2;
    ROS_INFO("request: %d, %d", req.num1, req.num2);
    ROS_INFO("ack: %d", ack.sum);

    return true;
}
 
int main(int argc, char *argv[])
{
    // 构造节点，节点句柄，服务端
    ros::init(argc, argv, "myServer");
    ros::NodeHandle nh;
    ros::ServiceServer server = nh.advertiseService("add_two_ints", AddAck);
    ROS_INFO("Ready to add two ints.");

    // 挂起并等待客户端请求
    ros::spin();

    return 0;
}
