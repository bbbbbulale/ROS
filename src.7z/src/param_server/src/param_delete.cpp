/*
    参数服务器操作之删除_C++实现:

    ros::NodeHandle
        deleteParam("键")
        根据键删除参数，删除成功，返回 true，否则(参数不存在)，返回 false

    ros::param
        del("键")
        根据键删除参数，删除成功，返回 true，否则(参数不存在)，返回 false

*/
#include "ros/ros.h"

// 法一
void DeleteFunction1(ros::NodeHandle nh, std::vector<std::string> param_d)
{
    for (size_t i = param_d.size(); i > 0; --i)
    {
        if (nh.deleteParam(param_d[i - 1]))
            ROS_INFO("ros::NodeHandle删除参数 %s 成功！", param_d[i - 1].c_str());
        else
            ROS_INFO("ros::NodeHandle删除参数 %s 失败！", param_d[i - 1].c_str());
    }
}

// 法二
void DeleteFunction2(std::vector<std::string> param_d)
{
    for (size_t i = param_d.size(); i > 0; --i)
    {
        if (ros::param::del(param_d[i - 1]))
            ROS_INFO("ros::param删除参数 %s 成功！", param_d[i - 1].c_str());
        else
            ROS_INFO("ros::param删除参数 %s 失败！", param_d[i - 1].c_str());
    }
}
int main(int argc, char *argv[])
{
    setlocale(LC_ALL, "");
    ros::init(argc, argv, "param_delete_node");
    ros::NodeHandle mynh;

    std::vector<std::string> param_to_delete = {"nh_int", "nh_map", "nh_string"};

    // 默认或参数为1时法一, 否则法二
    if (argc == 1 || atoi(argv[1]) == 1)
        DeleteFunction1(mynh, param_to_delete);
    else
        DeleteFunction2(param_to_delete);
    return 0;
}
