/*
    参数服务器操作之查询_C++实现:
    在 roscpp 中提供了两套 API 实现参数操作
    ros::NodeHandle
        param(键,默认值)
            存在，返回对应结果，否则返回默认值

        getParam(键,存储结果的变量)
            存在,返回 true,且将值赋值给参数2
            若果键不存在，那么返回值为 false，且不为参数2赋值

        getParamCached键,存储结果的变量)--提高变量获取效率
            存在,返回 true,且将值赋值给参数2
            若果键不存在，那么返回值为 false，且不为参数2赋值

        getParamNames(std::vector<std::string>)
            获取所有的键,并存储在参数 vector 中

        hasParam(键)
            是否包含某个键，存在返回 true，否则返回 false

        searchParam(参数1，参数2)
            搜索键，参数1是被搜索的键，参数2存储搜索结果的变量

    ros::param ----- 与 NodeHandle 类似

*/
#include "ros/ros.h"

void GetFunction1(ros::NodeHandle nh)
{
    int res1 = nh.param("nh_int", 0); // 非bool
    // param
    if (res1)
        ROS_INFO("param获取nh_int成功:%d", res1);
    else
        ROS_INFO("param获取nh_int失败,默认值0");

    // getParam & getParamCached
    double res_double;
    if (nh.getParamCached("nh_double", res_double)) // bool
        ROS_INFO("getParamCached获取nh_double成功:%.4f", res_double);
    else
    {
        ROS_INFO("getParamCached获取nh_double失败！");
        if (nh.getParam("nh_double", res_double))
            ROS_INFO("但getParam获取nh_double成功:%.4f", res_double);
        else
            ROS_INFO("且getParam获取nh_double也失败！");
    }

    // getParamNames
    std::vector<std::string> paramNames;
    if (nh.getParamNames(paramNames))
    {
        ROS_INFO("getParamNames获取参数列表成功：");
        for (auto &&name : paramNames)
            ROS_INFO("\t%s", name.c_str());
    }
    else
        ROS_INFO("getParamNames获取参数列表失败！");

    // hasParam
    if (nh.hasParam("nh_map"))
        ROS_INFO("存在参数nh_map！");
    else
        ROS_INFO("不存在参数nh_map！");

    // searchParam
    std::string key;
    if (nh.searchParam("nh_string", key))
        ROS_INFO("存在参数%s", key.c_str());
    else
        ROS_INFO("不存在参数nh_string");
}

void GetFunction2(void)
{
    ///ros::parap::...
}

int main(int argc, char *argv[])
{
    setlocale(LC_ALL, "");
    ros::init(argc, argv, "param_get_node");
    ros::NodeHandle mynh;

    // 默认或参数为1时法一, 否则法二
    if (argc == 1 || atoi(argv[1]) == 1)
        GetFunction1(mynh);
    else
        GetFunction2();
    return 0;
}
