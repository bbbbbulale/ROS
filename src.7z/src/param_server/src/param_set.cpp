/*
    参数服务器操作之新增与修改(二者API一样)_C++实现:
    在 roscpp 中提供了两套 API 实现参数操作
    ros::NodeHandle
        setParam("键",值)
    ros::param
        set("键","值")

    示例:分别设置整形、浮点、字符串、bool、列表、字典等类型参数
        修改(相同的键，不同的值)

*/
#include "ros/ros.h"

// 法一
void SetFunction1(ros::NodeHandle nh, std::vector<std::string> v, std::map<std::string, std::string> m)
{
    nh.setParam("nh_int", 10);
    ROS_INFO("ros::NodeHandle设置nh_int成功！");
    nh.setParam("nh_double", 3.1415);
    ROS_INFO("ros::NodeHandle设置nh_double成功！");
    nh.setParam("nh_bool", true);
    ROS_INFO("ros::NodeHandle设置nh_bool成功！");
    nh.setParam("nh_string", "hello!");
    ROS_INFO("ros::NodeHandle设置nh_string成功！");
    nh.setParam("nh_vector", v);
    ROS_INFO("ros::NodeHandle设置nh_vector成功！");
    nh.setParam("nh_map", m);
    ROS_INFO("ros::NodeHandle设置nh_map成功！");
    // 修改
    nh.setParam("nh_string", "nani???");
    ROS_INFO("ros::NodeHandle修改nh_string成功！");
}

// 法二
void SetFunction2(std::vector<std::string> v, std::map<std::string, std::string> m)
{
    ros::param::set("nh_int", 10);
    ROS_INFO("ros::param设置nh_int成功！");
    ros::param::set("nh_double", 3.1415);
    ROS_INFO("ros::param设置nh_double成功！");
    ros::param::set("nh_bool", true);
    ROS_INFO("ros::param设置nh_bool成功！");
    ros::param::set("nh_string", "hello!");
    ROS_INFO("ros::param设置nh_string成功！");
    ros::param::set("nh_vector", v);
    ROS_INFO("ros::param设置nh_vector成功！");
    ros::param::set("nh_map", m);
    ROS_INFO("ros::param设置nh_map成功！");
    // 修改
    ros::param::set("nh_string", "what???");
    ROS_INFO("ros::param修改nh_string成功！");
}
int main(int argc, char *argv[])
{
    setlocale(LC_ALL, "");
    ros::init(argc, argv, "param_set_node");
    ros::NodeHandle mynh;

    std::vector<std::string> myvector = {"要", "鑫", "海"};
    std::map<std::string, std::string> mymap = {{"他", "男孩"}, {"她", "女孩"}};

    // 默认或参数为1时法一, 否则法二
    if (argc == 1 || atoi(argv[1]) == 1)
        SetFunction1(mynh, myvector, mymap);
    else
        SetFunction2(myvector, mymap);

    return 0;
}
