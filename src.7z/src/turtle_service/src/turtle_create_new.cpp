#include "ros/ros.h"
#include "turtlesim/Spawn.h"

bool InitSpawnMsg(int argc_, char *argv_[], turtlesim::Spawn &msg_);

int main(int argc, char *argv[])
{
    turtlesim::Spawn msg;
    if (InitSpawnMsg(argc, argv, msg) == false)
        return 1;

    ros::init(argc, argv, "turtle_create_new_node");
    ros::NodeHandle nh;
    ros::ServiceClient client = nh.serviceClient<turtlesim::Spawn>("/spawn");

    client.waitForExistence();
    if (client.call(msg) == true)
        ROS_INFO("Successfully create new turtle '%s'", msg.response.name.c_str());
    else
    {
        ROS_WARN("Failed to call service /spawn!");
        return 1;
    }

    return 0;
}

bool InitSpawnMsg(int argc_, char *argv_[], turtlesim::Spawn &msg_)
{
    msg_.request.x = msg_.request.y = 5.54;
    switch (argc_ - 1)
    {
    case 0: // 默认名字
        break;
    case 1:
        ROS_INFO("\nargc:%d \nargv: %s", argc_, argv_[1]); // name
        msg_.request.name = argv_[1];
        break;
    case 2:
        ROS_INFO("\nargc:%d \nargv: %s %s", argc_, argv_[1], argv_[2]); // x y
        msg_.request.x = atof(argv_[1]);
        msg_.request.y = atof(argv_[2]);
        break;
    case 3:
        ROS_INFO("\nargc:%d \nargv: %s %s %s", argc_, argv_[1], argv_[2], argv_[3]); // name x y
        msg_.request.name = argv_[1];
        msg_.request.x = atof(argv_[2]);
        msg_.request.y = atof(argv_[3]);
        break;
    case 4:
        ROS_INFO("\nargc:%d \nargv: %s %s %s %s",
                 argc_, argv_[1], argv_[2], argv_[3], argv_[4]); // name x y theta
        msg_.request.name = argv_[1];
        msg_.request.x = atof(argv_[2]);
        msg_.request.y = atof(argv_[3]);
        msg_.request.theta = atof(argv_[4]);
        break;
    default:
        ROS_INFO("Invalid arguments!");
        return false;
        break;
    }
    return true;
}
