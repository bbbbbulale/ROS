#！/usr/bin/env python
import rospy, sys
from turtlesim.srv import Spawn, SpawnRequest

def InitSpawnReq(args, req_):    
    req_.x = req_.y = 5.54  
    try:
        # name  
        if len(args) == 2:  
            req_.name = args[1]  
        # x y 
        if len(args) == 3:   
                req_.x = float(args[1])  
                req_.y = float(args[2])  
        # name x y
        if len(args) == 4:  
                req_.name = args[1]
                req_.x = float(args[2])  
                req_.y = float(args[3])     
        # name x y theta 
        if len(args) == 5:   
                req_.name = args[1]
                req_.x = float(args[2])  
                req_.y = float(args[3])  
                req_.theta = float(args[4])  
    except ValueError:  
        rospy.logwarn("Invalid arguments")  
        return False  
    return True   

if __name__ == "__main__":
    req = Spawn._request_class()
    if not InitSpawnReq(sys.argv, req):
        sys.exit(1)
    
    rospy.init_node("turtle_create_new_node")
    client = rospy.ServiceProxy("/spawn", Spawn)
    client.wait_for_service()
        
    try:
        name = client.call(req)
        rospy.loginfo("Successfully create new turtle '%s'", name)
    except rospy.ServiceException as e:
        rospy.logerr("Failed to call service /spawn!\nError messages: %s", e) 