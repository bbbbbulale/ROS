#! /usr/bin/env python
import rospy

if __name__ == "__main__":
    rospy.init_node("turtle_set_color_node")
    rospy.set_param("turtle_GUI/background_r", 0)
    rospy.set_param("turtle_GUI/background_g", 0)
    rospy.set_param("turtle_GUI/background_b", 0)