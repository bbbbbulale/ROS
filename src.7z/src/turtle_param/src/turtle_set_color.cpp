#include "ros/ros.h"

int main(int argc, char *argv[])
{
    ros::init(argc, argv, "turtle_set_color_node");
    ros::NodeHandle nh("turtle_GUI"); //设置命名空间为turtlesim
    
    nh.setParam("background_r", 255);  //设置的参数为turtlesim/background_r
    nh.setParam("background_g", 255);
    nh.setParam("background_b", 255);

    return 0;
}
