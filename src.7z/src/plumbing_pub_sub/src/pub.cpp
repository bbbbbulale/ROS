#include "ros/ros.h"
#include "std_msgs/String.h"
#include <sstream>

int main(int argc, char *argv[])
{
    setlocale(LC_ALL, "");
    // 初始化ROS节点
    ros::init(argc, argv, "publisher");

    // 创建节点句柄
    ros::NodeHandle nh;

    // 创建发布者对象
    ros::Publisher pub = nh.advertise<std_msgs::String>("mytopic", 10); //最大缓冲10条

    // 编写发布逻辑并发布数据
    std_msgs::String msg;
    uint16_t count = 0;
    std::stringstream ss;

    ros::Rate rate(1);//n Hz
    ros::Duration(1.0).sleep();

    while(ros::ok())
    {
        count++;
        ss.str(""); // 清空 

        ss << "hello ------> " << count;
        msg.data = ss.str();

        pub.publish(msg);
        ROS_INFO("发布的数据是：%s \n",  msg.data.c_str());

        ros::spinOnce(); // 官方推荐，可以不加
        rate.sleep();
    }

    return 0;
}
