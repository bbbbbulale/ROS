#include "ros/ros.h"
#include "std_msgs/String.h"

void MsgHandle(const std_msgs::String::ConstPtr &msg)
{
    // 处理订阅到的数据
    ROS_INFO("subscriber订阅的数据：%s", msg->data.c_str());
}

int main(int argc, char *argv[])
{
    setlocale(LC_ALL, "");
    // 初始化ROS节点
    ros::init(argc, argv, "subscriber");

    // 创建节点句柄
    ros::NodeHandle nh;

    // 创建订阅者对象
    ros::Subscriber sub = nh.subscribe("mytopic", 10, MsgHandle);

    ros::spin();

    return 0;
}
