#include "ros/ros.h"
#include "plumbing_pub_sub/Person.h"

// 订阅话题数据处理
void MsgHandle(const plumbing_pub_sub::Person::ConstPtr &person){
    ROS_INFO("我是张三，订阅收到的信息:%s, %d, %.2f", person->name.c_str(), person->age, person->height);
}

int main(int argc, char *argv[])
{   
    setlocale(LC_ALL,"");

    // 构造节点，节点句柄，话题订阅者
    ros::init(argc,argv,"student");
    ros::NodeHandle nh;
    ros::Subscriber sub = nh.subscribe<plumbing_pub_sub::Person>("chat", 10, MsgHandle);

    ros::spin();    
    return 0;
}
