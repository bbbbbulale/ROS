#include "ros/ros.h"
#include "plumbing_pub_sub/Person.h"

int main(int argc, char *argv[])
{
    setlocale(LC_ALL, "");

    // 构造节点，节点句柄，话题发布者
    ros::init(argc, argv, "teacher");
    ros::NodeHandle nh;
    ros::Publisher pub = nh.advertise<plumbing_pub_sub::Person>("chat", 10);

    // 构造话题消息
    plumbing_pub_sub::Person person;
    person.name = "张三";
    person.age = 24;
    person.height = 1.85;

    // 发布话题
    ros::Rate rate(1);
    while(ros::ok())
    {
        pub.publish(person);
        person.age += 1;
        ROS_INFO("我是老师，你是%s，今年%d岁，身高：%.2f米", person.name.c_str(), person.age, person.height);

        ros::spinOnce(); // 官方推荐，可以不加
        rate.sleep();
    }
    
    return 0;
}
