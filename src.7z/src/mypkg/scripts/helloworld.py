#! /usr/bin/env python

import rospy

if __name__ == "__main__":
    rospy.init_node("Hello")
    rospy.loginfo("Python: hello world!")

