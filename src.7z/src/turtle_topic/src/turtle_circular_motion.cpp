#include "ros/ros.h"
#include "geometry_msgs/Twist.h"

geometry_msgs::Twist MsgInit()
{
    geometry_msgs::Twist msg;
    msg.linear.x = 1.0;
    // msg.linear.y = 0.0;
    // msg.linear.z = 0.0;
    // msg.angular.x = 0.0;
    // msg.angular.y = 0.0;
    msg.angular.z = 1.0;
    return msg;
}

int main(int argc, char *argv[])
{
    setlocale(LC_ALL, "");
    ros::init(argc, argv, "turtle_circular_motion_node");
    ros::NodeHandle nh;
    ros::Publisher pub = nh.advertise<geometry_msgs::Twist>("/turtle1/cmd_vel", 100);

    ros::Rate rate = 1;
    geometry_msgs::Twist msg = MsgInit();
    ROS_INFO("\nargc:%d \nargv: %s, %s, %s", argc, argv[1], argv[2], argv[3]);
    if (argc >= 3)
    {
        msg.linear.x = std::stod(argv[1]);
        msg.angular.z = std::stod(argv[2]);
        if (argc == 4)
            rate = std::stod(argv[3]);
    }

    while (ros::ok())
    {
        pub.publish(msg);
        rate.sleep();

        ros::spinOnce(); // 官方建议，非必要
    }

    return 0;
}
