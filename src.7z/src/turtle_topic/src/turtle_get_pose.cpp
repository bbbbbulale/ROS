#include "ros/ros.h"
#include "turtlesim/Pose.h"

void ShowMsgPose(const turtlesim::Pose::ConstPtr& msg)
{
    ROS_INFO("x=%.2f, y=%.2f, theta=%.2f, linear_velocity=%.2f, angular_velocity=%.2f",
    msg->x, msg->y, msg->theta, msg->linear_velocity, msg->angular_velocity);
}

int main(int argc, char *argv[])
{
    ros::init(argc, argv, "turtle_get_pose_node");
    ros::NodeHandle nh;
    ros::Subscriber sub = nh.subscribe<turtlesim::Pose>("/turtle1/pose", 100, ShowMsgPose);
    ros::spin();
    
    return 0;
}
